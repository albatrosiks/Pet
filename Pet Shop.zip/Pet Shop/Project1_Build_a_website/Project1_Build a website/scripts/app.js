﻿var app = (function () {
    /* Properties */
    var websiteName = "PetShop";
    /* Methods */
    return {
        getWebsiteName: function () {
            return websiteName;
        }
    }
})();